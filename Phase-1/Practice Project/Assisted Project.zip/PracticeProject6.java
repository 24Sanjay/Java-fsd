package phase1;
import java.util.*;

public class PracticeProject6 {
    public static void main(String[] args) {
        
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Sandy", 25);
        hashMap.put("Priyanka", 30);
        hashMap.put("Makapa", 35);
        System.out.println("HashMap:");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }

        
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Vijay", 50);
        treeMap.put("Siva", 35);
        treeMap.put("Ajith", 58);
        System.out.println("\nTreeMap:");
        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }

        
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("Ronaldo", 31);
        linkedHashMap.put("Messi", 32);
        linkedHashMap.put("Neymer", 33);
        System.out.println("\nLinkedHashMap:");
        for (Map.Entry<String, Integer> entry : linkedHashMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }
}
