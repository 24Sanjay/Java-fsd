package phase1;
import java.util.*;

public class PracticeProject5 {
    public static void main(String[] args) {
        
        List<String> arrayList = new ArrayList<>();
        arrayList.add("King");
        arrayList.add("Queen");
        arrayList.add("Prince");
        System.out.println("ArrayList:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

        
        List<String> linkedList = new LinkedList<>();
        linkedList.add("Man");
        linkedList.add("Woman");
        linkedList.add("Boy");
        System.out.println("\nLinkedList:");
        for (String color : linkedList) {
            System.out.println(color);
        }

       
        Set<String> hashSet = new HashSet<>();
        hashSet.add("Sachin");
        hashSet.add("Dhoni");
        hashSet.add("Dravid");
        System.out.println("\nHashSet:");
        for (String animal : hashSet) {
            System.out.println(animal);
        }

        
        Map<Integer, String> hashMap = new HashMap<>();
        hashMap.put(1, "One");
        hashMap.put(2, "Two");
        hashMap.put(3, "Three");
        System.out.println("\nHashMap:");
        for (Map.Entry<Integer, String> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }
    }
}