package phase1;

public class PracticeProject1 {
    public static void main(String[] args) {
        
        double doubleNum = 70.5;
        int intNum = (int) doubleNum; 
        System.out.println("Double: " + doubleNum);
        System.out.println("Int: " + intNum);      
        intNum = 25;
        doubleNum = intNum; 
        System.out.println("Int: " + intNum);
        System.out.println("Double: " + doubleNum);
    }
}