package phase1;

public class PracticeProject8 {
    public static void main(String[] args) {
        
        String originalString = "Hello, itz me!";
        System.out.println("Original  " + originalString);

        
        StringBuffer stringBuffer = new StringBuffer(originalString);
        System.out.println("String converted to StringBuffer: " + stringBuffer);

        
        StringBuilder stringBuilder = new StringBuilder(originalString);
        System.out.println("String converted to StringBuilder: " + stringBuilder);
    }
}