package phase1;

public class PracticeProject9 {
    public static void main(String[] args) {
        
        int[] intArray = {21, 2, 23, 4, 25,};
        
        System.out.println("Integer Array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.println("Element at index " + i + ": " + intArray[i]);
        }

        
        String[] stringArray = {"Summer", "Winter", "Autumn", "Spring", "Seasons"};
        
       
        System.out.println("\nString Array:");
        for (int i = 0; i < stringArray.length; i++) {
            System.out.println("Element at index " + i + ": " + stringArray[i]);
        }

        
        intArray[2] = 10;
        System.out.println("\nUpdated Integer Array:");
        for (int i = 0; i < intArray.length; i++) {
            System.out.println("Element at index " + i + ": " + intArray[i]);
        }
    }
}