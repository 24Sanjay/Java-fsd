package phase1;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

public class PracticeProject24 {
    Node head;

    PracticeProject24() {
        head = null;
    }

    
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

   
    void delete(int key) {
        if (head == null) {
            System.out.println("List is empty. Nothing to delete.");
            return;
        }

        
        if (head.data == key) {
            head = head.next;
            return;
        }

        Node current = head;
        Node prev = null;

        
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

       
        if (current == null) {
            System.out.println("Key not found in the list. Nothing to delete.");
            return;
        }

        
        prev.next = current.next;
    }

   
    void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PracticeProject24 list = new PracticeProject24();

        System.out.print("Enter the number of elements in the linked list: ");
        int n = scanner.nextInt();
        System.out.println("Enter the elements of the linked list:");
        for (int i = 0; i < n; i++) {
            int data = scanner.nextInt();
            list.insert(data);
        }

        System.out.print("Enter the key to delete from the linked list: ");
        int key = scanner.nextInt();
        
        System.out.println("Original linked list:");
        list.display();

        
        list.delete(key);

        System.out.println("Linked list after deleting the first occurrence of " + key + ":");
        list.display();

        scanner.close();
    }
}