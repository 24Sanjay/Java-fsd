package phase1;
import java.util.Arrays;
import java.util.Scanner;

public class PracticeProject21 {
    
    public static int findFourthSmallest(int[] nums) {
        if (nums == null || nums.length < 4) {
            throw new IllegalArgumentException("Input array should have at least 4 elements");
        }
        
        Arrays.sort(nums);
        return nums[3];
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();
        
        int[] nums = new int[n];
        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
        
        int fourthSmallest = findFourthSmallest(nums);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
        
        
    }
}