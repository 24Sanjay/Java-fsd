package phase1;
import java.util.LinkedList;
import java.util.Queue;

public class PracticeProject28 {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        
        System.out.println("Enqueuing elements into the queue:");
        queue.add(101);
        queue.add(202);
        queue.add(303);
        queue.add(404);
        queue.add(505);

       
        System.out.println("Queue elements: " + queue);

        
        System.out.println("\nDequeuing elements from the queue:");
        while (!queue.isEmpty()) {
            int removedElement = queue.poll();
            System.out.println("Dequeued element: " + removedElement);
        }

        
        if (queue.isEmpty()) {
            System.out.println("\nThe queue is empty now.");
        } else {
            System.out.println("\nThe queue is not empty.");
        }
    }
}

