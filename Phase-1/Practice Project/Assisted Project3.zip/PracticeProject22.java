package phase1;
import java.util.Scanner;

public class PracticeProject22 {
    
    public static int findRangeSum(int[] nums, int L, int R) {
        if (nums == null || nums.length == 0 || L < 0 || R >= nums.length || L > R) {
            throw new IllegalArgumentException("Invalid input or range");
        }
        
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += nums[i];
        }
        return sum;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        
        int[] nums = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
        
        System.out.print("Enter the range (L and R where 0 <= L <= R <= n-1): ");
        int L = scanner.nextInt();
        int R = scanner.nextInt();
        
        try {
            int rangeSum = findRangeSum(nums, L, R);
            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + rangeSum);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        scanner.close();
    }
}