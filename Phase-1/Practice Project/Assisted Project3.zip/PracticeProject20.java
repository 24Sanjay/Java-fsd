package phase1;

import java.util.Scanner;

public class PracticeProject20 {
    
    public static void rightRotate(int[] nums, int k) {
        if (nums == null || nums.length == 0) return;
        
        int n = nums.length;
        k = k % n; 
        
        reverse(nums, 0, n - 1);
        reverse(nums, 0, k - 1);
        reverse(nums, k, n - 1);
    }
    
    public static void reverse(int[] nums, int start, int end) {
        while (start < end) {
            int temp = nums[start];
            nums[start] = nums[end];
            nums[end] = temp;
            start++;
            end--;
        }
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        
        int[] nums = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            nums[i] = scanner.nextInt();
        }
        
        int steps = 5;
        System.out.println("Original Array:");
        for (int num : nums) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        rightRotate(nums, steps);
        
        System.out.println("Array after right rotation by " + steps + " steps:");
        for (int num : nums) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        scanner.close();
    }
}