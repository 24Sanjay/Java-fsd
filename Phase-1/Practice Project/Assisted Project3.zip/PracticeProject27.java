package phase1;
import java.util.Stack;

public class PracticeProject27 {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        
        System.out.println("Inserting elements into the stack:");
        stack.push(101);
        stack.push(202);
        stack.push(303);
        stack.push(404);
        stack.push(505);

       
        System.out.println("Stack elements: " + stack);

        
        System.out.println("\nRemoving elements from the stack:");
        while (!stack.isEmpty()) {
            int removedElement = stack.pop();
            System.out.println("Popped element: " + removedElement);
        }

        
        if (stack.isEmpty()) {
            System.out.println("\nThe stack is empty now.");
        } else {
            System.out.println("\nThe stack is not empty.");
        }
    }
}

