package phase1;

import java.util.Scanner;

public class PracticeProject23 {
    
    public static int[][] multiplyMatrices(int[][] mat1, int[][] mat2) {
        int m1 = mat1.length;
        int n1 = mat1[0].length;
        int m2 = mat2.length;
        int n2 = mat2[0].length;
        
        if (n1 != m2) {
            throw new IllegalArgumentException("Number of columns of the first matrix must be equal to number of rows of the second matrix");
        }
        
        int[][] result = new int[m1][n2];
        
        for (int i = 0; i < m1; i++) {
            for (int j = 0; j < n2; j++) {
                for (int k = 0; k < n1; k++) {
                    result[i][j] += mat1[i][k] * mat2[k][j];
                }
            }
        }
        
        return result;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of rows of the first matrix: ");
        int m1 = scanner.nextInt();
        System.out.print("Enter the number of columns of the first matrix: ");
        int n1 = scanner.nextInt();
        
        int[][] mat1 = new int[m1][n1];
        System.out.println("Enter the elements of the first matrix:");
        for (int i = 0; i < m1; i++) {
            for (int j = 0; j < n1; j++) {
                mat1[i][j] = scanner.nextInt();
            }
        }
        
        System.out.print("Enter the number of rows of the second matrix: ");
        int m2 = scanner.nextInt();
        System.out.print("Enter the number of columns of the second matrix: ");
        int n2 = scanner.nextInt();
        
        int[][] mat2 = new int[m2][n2];
        System.out.println("Enter the elements of the second matrix:");
        for (int i = 0; i < m2; i++) {
            for (int j = 0; j < n2; j++) {
                mat2[i][j] = scanner.nextInt();
            }
        }
        
        scanner.close();
        
        try {
            int[][] result = multiplyMatrices(mat1, mat2);
            
            System.out.println("Resultant Matrix after multiplication:");
            for (int[] row : result) {
                for (int element : row) {
                    System.out.print(element + " ");
                }
                System.out.println();
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Matrix multiplication is not possible. " + e.getMessage());
        }
    }
}