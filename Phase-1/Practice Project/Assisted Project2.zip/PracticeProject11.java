package phase1;

class MyThread extends Thread {
    public void run() {
        System.out.println("Thread created by extending Thread class.");
    }
}

public class PracticeProject11 {
    public static void main(String[] args) {
        MyThread thread = new MyThread();
        thread.start(); 
    }
}