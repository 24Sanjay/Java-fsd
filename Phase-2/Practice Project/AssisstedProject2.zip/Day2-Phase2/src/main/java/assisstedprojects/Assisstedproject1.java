package assisstedprojects;
import java.sql.Connection;
import java.sql.DriverManager;

public class Assisstedproject1 {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2","root", "Sanjay@24");
			if(conObj!=null)
				System.out.println(" Db created successfully");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}
		// TODO Auto-generated method stub

	}


