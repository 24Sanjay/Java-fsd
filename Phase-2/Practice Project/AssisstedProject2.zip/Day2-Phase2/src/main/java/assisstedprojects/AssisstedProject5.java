package assisstedprojects;


import java.sql.*;


public class AssisstedProject5 {
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url1="jdbc:mysql://localhost:3306/";
			Connection con=DriverManager.getConnection(url1,"root","Sanjay@24");
			Statement stm= con.createStatement();
			String dbname="employee";
            String sql1 = "CREATE DATABASE "+dbname;
            stm.executeUpdate(sql1);
            System.out.println("Database created successfully!");
            String url2="jdbc:mysql://localhost:3306/"+dbname;
            Connection con1=DriverManager.getConnection(url2,"root","Sanjay@24");
            String sql2 = "DROP DATABASE "+dbname;
            stm.executeUpdate(sql2);
            System.out.println("Database dropped successfully!");
            con1.close();
            con.close();
            stm.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}



}