package assisstedprojects;
import java.sql.*;
public class AssisstedProject3 {

	public static void main(String[] args) {
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2","root","Sanjay@24");
			Statement stmt=con.createStatement();
			ResultSet res=stmt.executeQuery("SELECT * FROM Student");
			while(res.next())
			{
				String name=res.getString("STDNAME");
				String course=res.getString("COURSE");
				float fees=res.getFloat("FEES");
				int roll=res.getInt("ROLLNO"); 
				System.out.println(roll+" "+name+" "+course+" "+fees);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	


	}

}