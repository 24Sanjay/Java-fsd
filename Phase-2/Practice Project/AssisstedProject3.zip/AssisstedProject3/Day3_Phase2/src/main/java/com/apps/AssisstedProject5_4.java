package com.apps;
import java.util.HashMap;    
import org.hibernate.*;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.entities.question3;    
  
  
public class AssisstedProject5_4 {    
public static void main(String[] args) {    
   
    StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
      
    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
    Session session=factory.openSession();  
   
Transaction t=session.beginTransaction();    
    
HashMap<String,String> map1=new HashMap<String,String>();    
map1.put("Java is a programming language","John Milton");    
map1.put("Java is a platform","Ashok Kumar");    
    
HashMap<String,String> map2=new HashMap<String,String>();    
map2.put("Servlet technology is a server side programming","John Milton");    
map2.put("Servlet is an Interface","Ashok Kumar");    
map2.put("Servlet is a package","Rahul Kumar");    
    
question3 question1=new question3("What is Java?","Alok",map1);    
question3 question2=new question3("What is Servlet?","Jai Dixit",map2);    
    
session.persist(question1);    
session.persist(question2);    
    
t.commit();    
session.close();    
System.out.println("successfully stored");    
}    
}    

	